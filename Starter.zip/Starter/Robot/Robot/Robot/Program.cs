﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SharePoint;

namespace Robot
{
    class Program
    {
        private static string URL = "http://dev.contoso.com";
        private static string ListTitle = "Compras";

        static void Main(string[] args)
        {


            try
            {
                //ConsultarItens(URL, listTitle);

                CriarItens(10);
                // Console.ReadLine();
                // bool sucesso = Atualizar("Teste", "Atualizado");
                Apagar("Teste");

                Console.ReadLine();
            }
            catch (Exception e)
            {

                Console.WriteLine("Falha" + e.StackTrace);
                Console.ReadLine();
            }


        }

        private static bool Atualizar(string ValorAtual, string ValorNovo)
        {
            using (var site = new SPSite(URL))
            using (var web = site.RootWeb)
            {
                var catalogo = web.Lists[ListTitle];

                SPListItemCollection itemCol = catalogo.GetItems(GetQuery(ValorAtual));
                Console.WriteLine(itemCol.Count);
                foreach (SPListItem item in itemCol)
                {
                    Console.WriteLine("Atualizando : " + item["Title"]);
                    item["Title"] = ValorNovo + new Random().Next(1000);
                    //item["Ano"] = new Random().Next(1950, 2020);
                    //item["Diretor"] = Faker.NameFaker.Name();
                    item.Update();
                }

                Console.WriteLine("Pronto");
            }

            return true;
        }

        private static bool Apagar(string ValorAtual)
        {
            using (var site = new SPSite(URL))
            using (var web = site.RootWeb)
            {
                var catalogo = web.Lists[ListTitle];

                SPListItemCollection itemCol = catalogo.GetItems(GetQuery(ValorAtual));
                Console.WriteLine("Vai apagar " + itemCol.Count + " itens");

                while (itemCol.Count > 0)
                {
                    itemCol = catalogo.GetItems(GetQuery(ValorAtual));
                    Console.WriteLine("Apagando : " + itemCol[0]["Title"]);
                    itemCol[0].Delete();
                }

                Console.WriteLine("Pronto");
            }

            return true;
        }

        public static SPQuery GetQuery(string busca)
        {
            SPQuery Query = new SPQuery();
            Query.Query = "<Where><Contains><FieldRef Name=\"Title\" /><Value Type =\"Text\">" + busca + "</Value></Contais></Where>";
            return Query;

        }


        private static void CriarItens(int Total)
        {
            for (int i = 0; i < Total; i++)
            {
                Console.WriteLine("Criando item " + i);
                CriarItem();
            }
        }

        private static void CriarItem()
        {

            using (var site = new SPSite(URL))
            using (var web = site.RootWeb)
            {
                var catalogo = web.Lists[ListTitle];

                SPListItem item = catalogo.Items.Add();
                item["Title"] = "Teste " + new Random().Next(1000);
                item["Ano"] = new Random().Next(1950, 2020);
                item["Diretor"] = Faker.NameFaker.Name();

                item.Update();

                Console.WriteLine("Pronto");

            }
        }



        private static void ConsultarItens(string URL, string ListTitle)
        {
            using (var site = new SPSite(URL))
            using (var web = site.RootWeb)
            {
                var catalogo = web.Lists[ListTitle];

                foreach (SPListItem item in catalogo.Items)
                {
                    Console.WriteLine(item["Title"]);
                }
                Console.ReadLine();
            }
        }

    }
}

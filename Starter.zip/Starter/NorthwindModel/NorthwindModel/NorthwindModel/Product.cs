﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NorthwindModel.NorthwindModel
{
    /// <summary>
    /// This class contains the properties for Entity1. The properties keep the data for Entity1.
    /// If you want to rename the class, don't forget to rename the entity in the model xml as well.
    /// </summary>
    public partial class Product
    {
        //TODO: Implement additional properties here. The property Message is just a sample how a property could look like.
        // Properties in first database
        public int ProductId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string RetailPrice { get; set; }
        public string QuantityPerUnit { get; set; }
        // Properties in second database
        public string ProductManager { get; set; }
        public string Manufacturer { get; set; }
        public string CostBasis { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace imdb
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {
        public string GetData(int value)
        {
            return string.Format("You entered: {0}", value);
        }

        public CompositeType GetDataUsingDataContract(CompositeType composite)
        {
            if (composite == null)
            {
                throw new ArgumentNullException("composite");
            }
            if (composite.BoolValue)
            {
                composite.StringValue += "Suffix";
            }
            return composite;
        }

        public int GetDobro(int nr)
        {
            return nr * 2;
        }


        public int GetQuadros(int nr)
        {
            return GetDobro(nr) * 2;
        }

        public Filme GetFilme(int Id)
        {
            //return new Filme
            //{
            //    ID = Id,
            //    Titulo = Titulo,
            //    Diretor = Diretor,
            //    Ano = Ano
            //};

            //return GetFilmes("where ID = " + Id)[0];
            return GetFilmes(GetFiltro("Id", Id)).First();
        }

        public string GetFiltro(string coluna, string valor)
        {
            return ((coluna != null) && (valor != null) ? (string.Format("where {0} like '%{1}%'", coluna, valor)) : "");
        }

        public string GetFiltro(string coluna, int valor)
        {
            return ((coluna != null) && (valor != null) ? (string.Format("where {0} = {1}", coluna, valor)) : "");
        }

        public List<Filme> GetFilmes(string coluna, string valor)
        {
            return GetFilmes(GetFiltro(coluna, valor));
        }

        public List<Filme> GetFilmes(string filtro)
        {
            SqlConnection conn = new SqlConnection("Data Source=London;Initial Catalog=Filmes;Integrated Security=True");

            try
            {
                conn.Open();

                SqlCommand cmd = conn.CreateCommand();
                cmd.CommandText = "select * from Catalogo " + filtro;

                SqlDataReader reader = cmd.ExecuteReader();

                var listaFilmes = new List<Filme>();

                while (reader.Read())
                {
                    listaFilmes.Add(new Filme
                    {
                        ID = int.Parse(reader["ID"].ToString()),
                        Titulo = reader["Titulo"].ToString(),
                        Diretor = reader["Diretor"].ToString(),
                        Ano = int.Parse(reader["Ano"].ToString())
                    });
                }

                return listaFilmes;
            }
            catch (Exception)
            {

                throw;
            }
        }
    }


}
